#- ejemplo incial sobre repeticiones y loops
#- PERO: @brodriguesco: New video: Don't write loops in R https://youtu.be/3xIKZbZKCWQ

for (ii in 1:10) {
  print(ii)
}


for (ii in 1:10) {
  print(2 + ii)
}


for (ii in 1:10) {
  aa <- paste("Repetición nº:", ii)
  print(aa)
}



#-------------------  rep() https://psyteachr.github.io/msc-data-skills/func.html
rep("A", 12)
rep(c("A", "B"), 12)
rep(c("A", "B"), times = 12)

rep(c("A", "B"), c(11, 3))

rep(c("A", "B"), each = 12)

rep(c("A", "B"), times = 3, each = 2)


#------------- seq()
seq(0, 10)
seq(0, 100, by = 10)
seq(0, 100, length.out = 5)

