#- script para seguir las slides_04_cargar-datos

#- pp. 4 -----------------------------------------------------------------------
#- Tarea: descargar un fichero de datos con R

#- Solución (I)

my_url <- "https://raw.githubusercontent.com/perezp44/archivos_download/refs/heads/master/plazas_turisticas.csv"


download.file(my_url, "plazas_turisticas.csv")

download.file(url = my_url,
              destfile = "plazas_turisticas.csv")


#- Solución (II)

my_url <- "https://raw.githubusercontent.com/perezp44/archivos_download/refs/heads/master/plazas_turisticas.csv"

fs::dir_create("pruebas")

download.file(my_url, "./pruebas/plazas_turisticas.csv")

download.file(url = my_url,
              destfile = "./pruebas/plazas_turisticas.csv")

#- Extended solution

my_url <- "https://raw.githubusercontent.com/perezp44/archivos_download/refs/heads/master/plazas_turisticas.csv"

my_ruta <- "./pruebas/plazas_turisticas.csv"


curl::curl_download(url = my_url,
                    destfile = my_ruta)

#- pp. 6 -----------------------------------------------------------------------
#- intenta entender el siguiente chunk de código

#- cuando iniciamos R se cargan automáticamente un grupo de paquetes (R-base)
print(.packages()) #- [🌶]imprimimos los nombres de los "currently attached packages"

#- en uno de esos paquetes hay un conjunto de datos llamado "iris"
iris          #- llamamos a "iris"
find("iris")  #- [🌶] ¿donde está iris?
str(iris)     #- qué es iris?


my_iris <- iris  #- "hacemos una copia" de iris en el Global
find("my_iris")  #- ¿donde está my_iris?

iris <- c(2, 4)    #- creamos un vector llamado iris
find("iris")       #- ¿donde está ahora iris?



rm(list = ls())


#- pp. 7 -----------------------------------------------------------------------
#- Tarea: usar unos datos de un paquete

#- Solución

#- install.packages("refugees")
library(refugees)

my_flows <- flows



#- Extended solution

my_flows_2 <- refugees::flows



rm(list = ls())   # borramos el Global

#- pp. 12 ----------------------------------------------------------------------
#- Tarea: importar a R datos que tenemos guardados en nuestro ordenador

#- Solución

my_ruta <- "./pruebas/plazas_turisticas.csv"

df <- rio::import(my_ruta)


#- Extended solution

my_ruta <- "./pruebas/plazas_turisticas.csv"

df <- rio::import(file = my_ruta)


rm(list = ls())   # borramos el Global


#- pp. 16 ----------------------------------------------------------------------
#- Tarea: exportar unos datos de R a un fichero


#- Solución

df <- iris

rio::export(df, "iris.csv")

rio::export(x = df,
            file = "iris.csv")


#- Solución (II)

rio::export(df, "./pruebas/iris.csv")

rio::export(x = df,
            file = "./pruebas/iris.csv")


#- pp. 17 ----------------------------------------------------------------------
#- Práctica: importar/exportar datos

#- antes borramos ./pruebas/
fs::dir_delete("pruebas")
fs::dir_create("pruebas")


#- Solución (está vez has de hacerlo tú)

# 1. Descargando los datos

#- en esta url hay un fichero de datos en formato .csv
my_url <- "https://raw.githubusercontent.com/perezp44/iris_data/master/data/iris.csv"

curl::curl_download(url = my_url,
                    destfile =  "./pruebas/iris.csv")

# 2. Importando los datos
my_ruta <- "./pruebas/iris.csv"

iris <- rio::import(my_ruta)

# 3. Exportando los datos
rio::export(x = iris, file = "./pruebas/iris.xlsx")

rio::export(x = iris, file = "./pruebas/iris.rds")


#- Extensión(**)

here::here()

here::here("pruebas", "iris.csv")




rm(list = ls())   # borramos el Global


#- pp. 20 ----------------------------------------------------------------------
#- Formato .rds

#- exportar a .rds
rio::export(x = iris, file = "./pruebas/iris.rds")

saveRDS(iris, file = "./pruebas/iris.rds")            #- con base-R

readr::write_rds(iris, "./pruebas/iris.rds")          #- con pkg "readr"


#- importar de .rds
df <- rio::import(file = "./pruebas/iris.rds")

my_iris_1 <- readRDS("./pruebas/iris.rds")         #- con R-base

my_iris_2 <- readr::read_rds("./pruebas/iris.rds")  #- tidyverse


#- pp. 21 ----------------------------------------------------------------------
#- Formato .RData (o .rda)

#- exportar a .rda (o .RData)
#- guardamos los objetos mtcars e iris en un fichero llamado "mtcars_and_iris.RData"

save(mtcars, iris, file = "./pruebas/mtcars_and_iris.RData")

#- importar de .rda (o .RData)
load(file = "./pruebas/mtcars_and_iris.RData")


#- Extensión: Para importar .rda desde la web hay que usar load(url())

#- hay que usar load(url())
#- no funciona xq han borrado el archivo
df <- load(url("http://gedemced.uab.cat/images/POP_ENC_AMB_2014.Rdata"))

#- pero si aún así no funcionase, usa  repmis::source_data()
my_url <- "https://github.com/perezp44/LAU2boundaries4spain/blob/master/data/Provincias.rda?raw=true"
df <- load(url(my_url)) #- no funciona
df <- repmis::source_data(my_url)



#- pp. 23 ----------------------------------------------------------------------
#- Eurostat:

# install.packages("eurostat")
library(eurostat)

#- importamos los datos de la tabla "cult_emp_sex": "Cultural employment by sex"
df <- eurostat::get_eurostat("cult_emp_sex")


#- pp. 24 ----------------------------------------------------------------------
#- Practica: importar datos de Eurostat

library(eurostat)

#- podemos buscar un  "tema" con la f. search_eurostat()
my_tema <- "employment"

aa <- eurostat::search_eurostat(pattern = my_tema, type = "all")

#- elegimos un dataset; por ejemplo "hlth_silc_17"
my_table <- "hlth_silc_17"

#- da información sobre la Base de datos que estas buscando
eurostat::label_eurostat_tables(my_table)

#-  importamos los datos de "my_table" con get_eurostat()
df <- eurostat::get_eurostat(my_table, time_format = "raw", keepFlags = TRUE )

#- pedimos los descriptores/labels de las series
df_l <- eurostat::label_eurostat(df)


#- pp. 25 ----------------------------------------------------------------------
#- El paquete quantmod

library(quantmod)  #- install.packages("quantmod")

#- For stocks and shares, the yahoo source is used.
facebook  <- getSymbols(Symbols = 'F', src = 'yahoo', auto.assign = FALSE)
barChart(facebook)

#- For currencies and metals, the oanda source is used.
tc_euro_dolar <- getSymbols(Symbols = 'EUR/USD', src = 'oanda', auto.assign = FALSE)

#- For economics series, the FRED source is used.
Japan_GDP <- getSymbols(Symbols = 'JPNNGDP', src = 'FRED', auto.assign = FALSE)



#- BONUS de I/O ----------------------------------------------------------------


#- pp. 27 ----------------------------------------------------------------------
#- Bonus 1 (🌶🌶 … 🌶): exportar los datos de un df a un archivo .xlsx ya existente


#- Solución (I) (ya no funciona)
#- bonus: le añadimos un libro mas al archivo "./pruebas/iris.xlsx"

rio::export(iris, "./pruebas/iris.xlsx")  #- por si acaso lo hubiésemos borrado


rio::export(iris, "./pruebas/iris.xlsx", which = "iris_2")

#- lo mismo pero poniendo los nombres de los argumentos
rio::export(x = iris,
            file ="./pruebas/iris.xlsx",
            which = "iris_3")


#- Solución (II)
#- tenemos que usar el pkg openxlsx
library(openxlsx) #- pak::pak("openxlsx")

#- tenemos que crear un "Woorkbook" con la f. loadWorkbook()
my_workbook <- openxlsx::loadWorkbook("./pruebas/iris.xlsx")

#- ahora añadimos hojas/sheets al Woorkbook
openxlsx::addWorksheet(my_workbook, "iris_2")
openxlsx::addWorksheet(my_workbook, "my_mtcars")

#- ahora escribimos datos en las nuevas hojas/sheets q hemos creado
openxlsx::writeData(my_workbook, sheet = "iris_2",    x = iris)
openxlsx::writeData(my_workbook, sheet = "my_mtcars", x = mtcars)

#- exportamos/guardamos el archivo (con las nuevas sheets)
openxlsx::saveWorkbook(my_workbook, "./pruebas/iris.xlsx", overwrite = TRUE)




#- pp. 28 ----------------------------------------------------------------------
#- Bonus 2 (🌶🌶🌶): exportar 2 df’s en un único archivo .xlsx

rio::export(x = list(my_iris = iris, my_pinguinos = penguins),
            file = "./pruebas/my_iris_pinguinos.xlsx")


#- pp. 29 ----------------------------------------------------------------------
#- Bonus 3 (🌶🌶): importar una hoja/libro especifica de un archivo .xlsx

iris_1 <- rio::import("./pruebas/my_iris_pinguinos.xlsx")  #- solo importa el primer libro


pinguinos_1 <- rio::import("./pruebas/my_iris_pinguinos.xlsx", sheet = 2)


pinguinos_2 <- rio::import(file = "./pruebas/my_iris_pinguinos.xlsx",
                           sheet = "my_pinguinos")




#- pp. 30 ----------------------------------------------------------------------
#- Bonus 4: (!!!! 😱 😱) importamos todos los libros de un archivo .xlsx


library(readxl) #- necesitamos la función readxl::excel_sheet()

mys_sheets <- readxl::excel_sheets(here::here("pruebas", "my_iris_pinguinos.xlsx"))

#- con base::lapply()
my_dfs_list <- lapply(mys_sheets,
                      readxl::read_excel,
                      path = here::here("pruebas", "my_iris_pinguinos.xlsx"))
#- con purrr::map()
my_dfs_list <- purrr::map(mys_sheets,
                          readxl::read_excel,
                          path = here::here("pruebas", "my_iris_pinguinos.xlsx"))

#- Ok, pero ahora tenemos los 2 data.frames dentro de una lista ¿qué hacemos?
#- Extrayendo un data.frame de una lista: con [[]]
my_iris <- my_dfs_list[[1]]




#- pp. 31 ----------------------------------------------------------------------
#- Bonus 5: (!!!!!!) importamos todos archivos de datos de una carpeta concreta

#- importamos todos los archivos que hemos creado en "./pruebas/"
library(purrr)
my_carpeta <- here::here("pruebas")

lista_de_archivos <- fs::dir_ls(my_carpeta)  #- pero mejor con el pkg "fs"

my_dfs_list_2 <- map(lista_de_archivos, rio::import)




#- EXTENSIONES -----------------------------------------------------------------


#- pp. 33 ----------------------------------------------------------------------
#- Webscrapping [🌶🌶🌶 🌶🌶]


library(rvest)
library(tidyverse)
my_url <- "https://es.wikipedia.org/wiki/Anexo:Municipios_de_la_provincia_de_Teruel"
content <- read_html(my_url)

body_table <- content %>%
  html_nodes('body')  %>%
  html_nodes('table') %>%
  html_table(dec = ",")

#- solo hay una tabla
Teruel <- body_table[[1]]  #- estoy haciendo subsetting de una lista


#- podemos arreglar un poco la tabla (!!!!!!!!)

names(Teruel) <- c("Nombre",  "Poblacion", "Superficie",
                   "Densidad", "Altitud", "Comarca", "Partido_judicial")
library(stringr)
Teruel <- Teruel %>% map(str_trim) %>% as_tibble() #- quita caracteres al final
Teruel <- Teruel %>% mutate(Altitud = str_replace_all(Altitud,"[[:punct:]]", ""))
Teruel <- Teruel %>% mutate(Altitud = as.double(Altitud)) %>% arrange(desc(Altitud))



#- pp. 34----------------------------------------------------------------------

typeof(iris)
class(iris)
names(attributes(iris))


iris_2 <- tibble::as_tibble(iris)
typeof(iris_2)
class(iris_2)
names(attributes(iris_2))



#- pp. 35 ----------------------------------------------------------------------
#- seleccionando “manualmente” un archivo de datos
my_data <- rio::import(file.choose())




#- pp. 36 ----------------------------------------------------------------------
#- gestionando las rutas con here::here()

here::here()  #- devuelve la ruta del directorio de trabajo

my_ruta <- here::here("datos", "my_archivo.csv")



#- pp. 37 ----------------------------------------------------------------------
#- ¿cómo construir nuestra rutas con here::here()?

rio::export(iris, file = "./pruebas/iris.xlsx" )

rio::export(iris, file = here::here("pruebas", "iris.xlsx" ))

here::here("pruebas", "iris.xlsx")


#- pp. 38 ----------------------------------------------------------------------
#- vamos a usar un bucle for . . . para exportar varios archivos
#- la solución en un ejemplo





#- pp. 42 ----------------------------------------------------------------------
#- Un caso más complejo

#- Solución con `rio`

rm(list = ls())  #- antes vamos a limpiar el Global env.

my_url <- "https://www.ine.es/daco/daco42/codmun/codmun20/20codmun.xlsx"

my_ruta_guardar <- here::here("pruebas", "20codmun.xlsx")

curl::curl_download(my_url, my_ruta_guardar) #- lo guardo en disco

df_1 <- rio::import(my_ruta_guardar) #- q pb tenemos?



#- Solución por menús
# Seguid la siguiente ruta de menús: File > Import Dataset > From Excel ...
# Pegáis en la caja de texto el url y pincháis el botón update


#- Solución con el pkg `readxl`

df_2 <- readxl::read_xlsx(my_url, skip = 1)  #- no funciona. readxl solo lee del PC

my_ruta_guardar <- here::here("pruebas", "20codmun.xlsx")

df_2 <- readxl::read_xlsx(my_ruta_guardar, skip = 1)



#- Solución "pofesional"

#- script para bajar la relación de municipios INE a 1 de enero de 2021
url_descarga <- "https://www.ine.es/daco/daco42/codmun/diccionario21.xlsx"
nombre_fichero <- "diccionario21.xlsx"

#- obtengo el nombre del archivo
nombre_fichero <- stringr::str_extract(url_descarga, "([^\\/]+$)")

#- añado la fecha de descarga al nombre de archivo
extension <- stringr::str_extract(url_descarga, "([^\\.]+$)")
nombre <- stringr::str_remove(nombre_fichero, paste0(".",extension))
nombre_fichero <- paste0(nombre , "_", Sys.Date(), ".", extension)

#- lo guardo
my_ruta <- here::here("pruebas", nombre_fichero) #- ruta para guardar el fichero
curl::curl_download(url = url_descarga, destfile = my_ruta)


#- importo al Global

df <- readxl::read_xlsx(path = my_ruta, skip = 1)

#- la verdad es que skip = 1 también hubiese funcionado con el paquete `rio`
#- ya que `rio` llama a `readxl`


#- pp. 43 ----------------------------------------------------------------------
#- seguimos con el ejemplo

library(tidyverse)

df <- df %>%
  mutate(ine_muni = paste0(CPRO, CMUN)) %>%
  mutate(year = "2021") %>%          #- !! cómo lo guardaría?
  mutate(year = as.numeric(year)) %>%
  rename(ine_muni.n = NOMBRE) %>%
  rename(ine_prov = CPRO) %>%
  select(ine_muni, ine_muni.n, ine_prov, year)

str(df)

#- Si quisiera exportar el archivo
readr::write_csv(df, file = here::here("pruebas", "my_relacion_muni_2021.csv"))



#- Podemos contar el nº de municipios por provincia (de muchas maneras distintas)
df_muni <- df %>% group_by(ine_prov) %>% summarise(numero_muni = n())
df_muni <- df %>% count(ine_prov)


#- Si quisiéramos saber el nombre de las provincias
#- pak::pak("perezp44/pjpv.curso.R.2022")
codigos_prov <- pjpv.curso.R.2022::ine_pob_mun_1996_2021 %>%
  select(ine_prov, ine_prov.n) %>%
  distinct()


#- fusiono los 2 ficheros (lo veremos!!)
df_ok <- left_join(df_muni, codigos_prov)


#- Borro la carpeta (para dejar el Rproject limpio)
fs::dir_delete("pruebas")  #- [🌶] borro la carpeta pruebas




